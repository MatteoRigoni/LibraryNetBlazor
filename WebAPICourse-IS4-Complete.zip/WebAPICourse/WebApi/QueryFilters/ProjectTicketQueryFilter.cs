﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.QueryFilters
{
    public class ProjectTicketQueryFilter
    {
        public string Owner { get; set; }
    }
}
